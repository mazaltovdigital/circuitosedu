# 🚀 Guia Completo de Implantação do Backend CircuitosEdu

Este guia fornece instruções detalhadas para hospedar o backend do CircuitosEdu em diferentes plataformas de nuvem, garantindo que o chatbot com IA funcione perfeitamente.

## 📋 Pré-requisitos

Antes de começar, certifique-se de ter:

- ✅ Conta no GitHub
- ✅ Chave da API da OpenAI (com créditos disponíveis)
- ✅ Conta em uma plataforma de hospedagem (Heroku, Render, Railway, etc.)

## 🎯 Opção 1: Heroku (Recomendado para Iniciantes)

### Passo 1: Preparação dos Arquivos

1. **Clone ou baixe o projeto** para seu computador
2. **Verifique se os seguintes arquivos estão presentes:**
   - `app.py` (servidor Flask)
   - `requirements.txt` (dependências)
   - `Procfile` (configuração do Heroku)
   - `runtime.txt` (versão do Python)

### Passo 2: Criação da Conta no Heroku

1. Acesse [heroku.com](https://heroku.com)
2. Crie uma conta gratuita
3. Instale o [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli)

### Passo 3: Deploy via GitHub (Método Mais Fácil)

1. **Faça push dos arquivos para seu repositório GitHub:**
   ```bash
   git add .
   git commit -m "Adiciona backend do CircuitosEdu"
   git push origin main
   ```

2. **No painel do Heroku:**
   - Clique em "New" → "Create new app"
   - Escolha um nome único (ex: `circuitosedu-backend-2024`)
   - Selecione a região mais próxima

3. **Configure o deploy automático:**
   - Vá para a aba "Deploy"
   - Selecione "GitHub" como método de deploy
   - Conecte sua conta GitHub
   - Busque e selecione seu repositório
   - Ative "Automatic deploys" (opcional)
   - Clique em "Deploy Branch"

### Passo 4: Configuração da Chave da API

1. **No painel do Heroku, vá para "Settings"**
2. **Clique em "Reveal Config Vars"**
3. **Adicione a variável:**
   - **KEY:** `OPENAI_API_KEY`
   - **VALUE:** `sua-chave-da-openai-aqui`

### Passo 5: Teste do Backend

1. **Acesse a URL do seu app:** `https://seu-app-name.herokuapp.com`
2. **Teste o endpoint de saúde:** `https://seu-app-name.herokuapp.com/health`
3. **Você deve ver uma resposta JSON confirmando que está funcionando**

## 🎯 Opção 2: Render (Alternativa Gratuita)

### Passo 1: Preparação

1. Acesse [render.com](https://render.com)
2. Crie uma conta gratuita
3. Conecte sua conta GitHub

### Passo 2: Deploy

1. **Clique em "New" → "Web Service"**
2. **Conecte seu repositório GitHub**
3. **Configure o serviço:**
   - **Name:** `circuitosedu-backend`
   - **Environment:** `Python 3`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python app.py`

### Passo 3: Configuração da Chave da API

1. **Na seção "Environment Variables"**
2. **Adicione:**
   - **Key:** `OPENAI_API_KEY`
   - **Value:** `sua-chave-da-openai-aqui`

3. **Clique em "Create Web Service"**

## 🎯 Opção 3: Railway (Rápido e Simples)

### Passo 1: Deploy Direto do GitHub

1. Acesse [railway.app](https://railway.app)
2. Faça login com GitHub
3. Clique em "New Project" → "Deploy from GitHub repo"
4. Selecione seu repositório

### Passo 2: Configuração

1. **Railway detectará automaticamente que é um projeto Python**
2. **Adicione a variável de ambiente:**
   - Vá para "Variables"
   - Adicione `OPENAI_API_KEY` com sua chave da API

## ⚙️ Configuração do Frontend

Após hospedar o backend, você precisa atualizar o frontend para apontar para a URL correta.

### Passo 1: Edite o arquivo `js/config.js`

```javascript
const API_CONFIG = {
    // Substitua pela URL do seu backend hospedado
    BASE_URL: 'https://seu-app-name.herokuapp.com', // ou render.com, railway.app, etc.
    TIMEOUT: 30000,
    ENDPOINTS: {
        CHAT: '/chat',
        HEALTH: '/health'
    }
};
```

### Passo 2: Faça o commit e push das alterações

```bash
git add js/config.js
git commit -m "Atualiza URL do backend para produção"
git push origin main
```

## 🔧 Solução de Problemas

### Problema: "Application Error" no Heroku

**Solução:**
1. Verifique os logs: `heroku logs --tail -a seu-app-name`
2. Certifique-se de que o `Procfile` está correto
3. Verifique se todas as dependências estão no `requirements.txt`

### Problema: Chatbot não responde

**Possíveis causas:**
1. **Backend não está rodando:** Verifique se o serviço está ativo
2. **URL incorreta no frontend:** Verifique o `js/config.js`
3. **Chave da API inválida:** Verifique se a chave da OpenAI está correta
4. **CORS bloqueado:** O backend já está configurado para aceitar requisições de qualquer origem

### Problema: Erro 429 (Rate Limit)

**Solução:**
- Sua chave da OpenAI atingiu o limite de requisições
- Aguarde ou adicione créditos à sua conta OpenAI

## 📊 Monitoramento

### Verificação de Saúde

Sempre teste estes endpoints após o deploy:

1. **Endpoint raiz:** `https://sua-url/`
2. **Saúde da API:** `https://sua-url/health`
3. **Teste de chat:** Use um cliente REST ou o próprio frontend

### Logs

- **Heroku:** `heroku logs --tail -a seu-app-name`
- **Render:** Acesse o dashboard e vá para "Logs"
- **Railway:** Acesse o projeto e vá para "Deployments"

## 🔒 Segurança

### Boas Práticas

1. **Nunca commite a chave da API no código**
2. **Use sempre variáveis de ambiente**
3. **Mantenha as dependências atualizadas**
4. **Configure HTTPS (já incluído nas plataformas mencionadas)**

### Exemplo de `.env` para desenvolvimento local

```env
OPENAI_API_KEY=sua-chave-aqui
FLASK_ENV=development
PORT=5000
```

## 🎉 Conclusão

Após seguir este guia, seu backend estará rodando na nuvem e o chatbot do CircuitosEdu estará totalmente funcional com IA da OpenAI!

### URLs Finais

- **Frontend (GitHub Pages):** `https://seu-usuario.github.io/circuitosedu`
- **Backend (Heroku/Render/Railway):** `https://seu-app-name.plataforma.com`

### Próximos Passos

1. Teste todas as funcionalidades
2. Configure monitoramento (opcional)
3. Documente para sua equipe
4. Considere configurar um domínio personalizado (opcional)

---

**🚀 Parabéns! Seu ambiente virtual de aprendizagem está pronto para uso!**

