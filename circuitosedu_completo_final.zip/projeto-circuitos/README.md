# CircuitosEdu - IA e Simulações Interativas no Ensino de Circuitos Elétricos CA

Uma plataforma educacional que integra simulações PHET com inteligência artificial para facilitar o aprendizado de circuitos elétricos de corrente alternada em cursos técnicos de automação industrial.

## 🎯 Sobre o Projeto

O CircuitosEdu é uma ferramenta educacional desenvolvida para estudantes de ensino técnico em automação industrial. A plataforma combina:

- **Simulações Interativas PHET**: Experimentos virtuais seguros e econômicos
- **Chatbot com IA**: Assistente virtual especializado em circuitos CA, motores e automação
- **Material Didático**: Conteúdo teórico estruturado sobre circuitos série, paralelo e misto
- **Recursos de RA**: Integração com realidade aumentada através do SENAI Space

## 🚀 Funcionalidades

### Simulações Interativas
- Circuitos em série, paralelo e misto
- Integração com simulador PHET
- Instruções passo a passo para cada tipo de circuito
- Interface responsiva para desktop e mobile

### Chatbot Inteligente
- Conectado ao ChatGPT da OpenAI
- Especializado em:
  - Circuitos de corrente alternada (CA)
  - Motores DC e trifásicos
  - Sensores indutivos e capacitivos
  - Automação industrial
  - Valores comerciais de componentes
- Respostas em tempo real
- Sistema de fallback para funcionamento offline

### Material Didático
- Explicações teóricas detalhadas
- Diagramas ilustrativos
- Exemplos práticos
- Referências acadêmicas

## 🛠️ Tecnologias Utilizadas

### Frontend
- HTML5, CSS3, JavaScript
- Bootstrap 5 (interface responsiva)
- Font Awesome (ícones)
- PHET Simulations (simulações)

### Backend
- Python 3.11
- Flask (API REST)
- OpenAI API (ChatGPT integration)
- CORS support

## 📦 Estrutura do Projeto

```
projeto-circuitos/
├── index.html              # Página principal
├── css/
│   └── styles.css          # Estilos customizados
├── js/
│   ├── script.js           # Lógica principal
│   └── config.js           # Configuração da API
├── img/                    # Imagens e diagramas
├── app.py                  # Backend Flask
├── requirements.txt        # Dependências Python
├── Procfile               # Configuração Heroku
├── runtime.txt            # Versão Python
└── README.md              # Este arquivo
```

## 🚀 Como Usar

### Opção 1: Apenas Frontend (GitHub Pages)

1. **Clone o repositório:**
   ```bash
   git clone https://github.com/seu-usuario/circuitosedu.git
   cd circuitosedu
   ```

2. **Abra o arquivo `index.html` no navegador**

   O chatbot funcionará em modo limitado (sem IA da OpenAI).

### Opção 2: Frontend + Backend (Funcionalidade Completa)

#### Pré-requisitos
- Python 3.11+
- Chave da API OpenAI
- Git

#### Instalação Local

1. **Clone o repositório:**
   ```bash
   git clone https://github.com/seu-usuario/circuitosedu.git
   cd circuitosedu
   ```

2. **Instale as dependências:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure a chave da API:**
   ```bash
   export OPENAI_API_KEY="sua-chave-aqui"
   ```

4. **Execute o backend:**
   ```bash
   python app.py
   ```

5. **Abra o arquivo `index.html` no navegador**

#### Deploy em Produção

Para deploy completo, consulte o [Guia de Implantação](GUIA_IMPLANTACAO.md) que inclui instruções para:
- Heroku
- Render
- Railway
- Outras plataformas

## ⚙️ Configuração

### Configuração da API

Edite o arquivo `js/config.js` para configurar a URL do backend:

```javascript
const API_CONFIG = {
    BASE_URL: 'https://seu-backend.herokuapp.com', // URL do seu backend
    TIMEOUT: 30000,
    ENDPOINTS: {
        CHAT: '/chat',
        HEALTH: '/health'
    }
};
```

### Variáveis de Ambiente

Para o backend, configure:

```bash
OPENAI_API_KEY=sua-chave-da-openai
PORT=5000
FLASK_ENV=production
```

## 🧪 Testes

### Teste do Frontend
1. Abra `index.html` no navegador
2. Verifique se as simulações PHET carregam
3. Teste a responsividade em diferentes dispositivos

### Teste do Backend
1. Acesse `http://localhost:5000/health`
2. Teste o endpoint de chat via POST request
3. Verifique os logs para erros

### Teste do Chatbot
1. Digite uma pergunta sobre circuitos CA
2. Verifique se a resposta é relevante e educativa
3. Teste diferentes tipos de perguntas

## 📚 Uso Educacional

### Para Professores
- Use as simulações para demonstrar conceitos
- Integre o chatbot como ferramenta de apoio
- Customize o conteúdo conforme necessário

### Para Estudantes
- Explore os diferentes tipos de circuitos
- Use o chatbot para esclarecer dúvidas
- Pratique com as simulações interativas

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 👥 Autores

- **Equipe CircuitosEdu** - *Desenvolvimento inicial*

## 🙏 Agradecimentos

- **PHET Interactive Simulations** - Simulações educacionais
- **OpenAI** - API do ChatGPT
- **SENAI** - Recursos de Realidade Aumentada
- **Bootstrap** - Framework CSS
- **Font Awesome** - Biblioteca de ícones

## 📞 Suporte

Para suporte e dúvidas:
- Abra uma [issue](https://github.com/seu-usuario/circuitosedu/issues)
- Email: circuitosedu@example.com

## 🔄 Atualizações

### Versão 2.0 (Atual)
- ✅ Integração com ChatGPT OpenAI
- ✅ Sistema de fallback inteligente
- ✅ Interface responsiva aprimorada
- ✅ Configuração simplificada para deploy

### Versão 1.0
- ✅ Simulações PHET integradas
- ✅ Chatbot básico com base de conhecimento local
- ✅ Material didático estruturado

---

**🚀 Transformando o ensino de circuitos elétricos com tecnologia e inovação!**

