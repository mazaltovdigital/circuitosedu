/**
 * Configuração da API do CircuitosEdu Chatbot
 * Este arquivo permite configurar facilmente a URL da API para diferentes ambientes
 */

const API_CONFIG = {
    // URL base da API do backend
    // Para desenvolvimento local: 'http://localhost:5000'
    // Para produção: substitua pela URL do seu backend hospedado (Heroku, Render, Railway, etc.)
    BASE_URL: 'http://localhost:5000',
    
    // Timeout para requisições (em milissegundos)
    TIMEOUT: 30000,
    
    // Endpoints disponíveis
    ENDPOINTS: {
        CHAT: '/chat',
        HEALTH: '/health'
    }
};

// Configuração automática baseada no ambiente
if (window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
    // Se não estiver rodando localmente, use a URL de produção
    // IMPORTANTE: Substitua pela URL real do seu backend hospedado
    API_CONFIG.BASE_URL = 'https://seu-backend-aqui.herokuapp.com';
}

// Torna a configuração disponível globalmente
window.CHATBOT_API_CONFIG = API_CONFIG;

